#Here . means current directory and product is a file import as a package and Product is a  class
from .product import Product
from .category import Category
from .customer import Customer
from .orders import Order
